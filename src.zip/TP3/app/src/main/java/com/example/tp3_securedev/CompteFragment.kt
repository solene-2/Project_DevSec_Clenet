package com.example.tp3_securedev

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.tp3_securedev.MainActivity.CompteSelect.name_compte
import com.example.tp3_securedev.MainActivity.CompteSelect.idA
import com.example.tp3_securedev.MainActivity.CompteSelect.accountName
import com.example.tp3_securedev.MainActivity.CompteSelect.amount
import com.example.tp3_securedev.MainActivity.CompteSelect.iban
import com.example.tp3_securedev.MainActivity.CompteSelect.currency
import java.io.FileInputStream
import java.io.ObjectInputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class CompteFragment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_compte)
    }

    override fun onStart(){
        super.onStart()

        try{
            //Reading
            FileInputStream("idA_map.dat")
            val idA_objectInputStream = ObjectInputStream(FileInputStream("idA_map.dat"))
            val idARead = idA_objectInputStream.readObject()
            idA_objectInputStream.close()
            val accountName_objectInputStream = ObjectInputStream(FileInputStream("accountName_map.dat"))
            val accountNameRead = accountName_objectInputStream.readObject()
            accountName_objectInputStream.close()
            val amount_objectInputStream = ObjectInputStream(FileInputStream("amount_map.dat"))
            val amountRead = amount_objectInputStream.readObject()
            amount_objectInputStream.close()
            val iban_objectInputStream = ObjectInputStream(FileInputStream("iban_map.dat"))
            val ibanRead = iban_objectInputStream.readObject()
            iban_objectInputStream.close()
            val currency_objectInputStream = ObjectInputStream(FileInputStream("currency_map.dat"))
            val currencyRead = currency_objectInputStream.readObject()
            currency_objectInputStream.close()

            //Decryption
            val idA_decrypted = decryptData(idARead as HashMap<String, ByteArray>, "UserSuppliedPassword")
            val accountName_decrypted = decryptData(accountNameRead as HashMap<String, ByteArray>, "UserSuppliedPassword")
            val amount_decrypted = decryptData(amountRead as HashMap<String, ByteArray>, "UserSuppliedPassword")
            val iban_decrypted = decryptData(ibanRead as HashMap<String, ByteArray>, "UserSuppliedPassword")
            val currency_decrypted = decryptData(currencyRead as HashMap<String, ByteArray>, "UserSuppliedPassword")

            //Screen display
            val id = findViewById<TextView>(R.id.text_idA)
            id.text =idA_decrypted.toString();
            val AN = findViewById<TextView>(R.id.text_account_name)
            AN.text =accountName_decrypted.toString();
            val amountA = findViewById<TextView>(R.id.text_amount)
            amountA.text =amount_decrypted.toString();
            val ibanA = findViewById<TextView>(R.id.text_iban)
            ibanA.text =iban_decrypted.toString();
            val currencyA = findViewById<TextView>(R.id.text_iban)
            currencyA.text =currency_decrypted.toString();
        }
        catch (e: Exception){
            val index = accountName.indexOf(name_compte);
            val id = findViewById<TextView>(R.id.text_idA)
            id.text =idA[index];
            val AN = findViewById<TextView>(R.id.text_account_name)
            AN.text =accountName[index];
            val amountA = findViewById<TextView>(R.id.text_amount)
            amountA.text =amount[index];
            val ibanA = findViewById<TextView>(R.id.text_iban)
            ibanA.text =iban[index];
            val currencyA = findViewById<TextView>(R.id.text_iban)
            currencyA.text =currency[index];
        }
        
        val buttonRet = findViewById<Button>(R.id.button_retour)
        buttonRet.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            this.startActivity(intent)
        }
    }
    private fun decryptData(map: HashMap<String, ByteArray>, passwordString: String): ByteArray? {
        var decrypted: ByteArray? = null
        try {
            val salt = map["salt"]
            val iv = map["iv"]
            val encrypted = map["encrypted"]

            //regenerate key from password
            val passwordChar = passwordString.toCharArray()
            val pbKeySpec = PBEKeySpec(passwordChar, salt, 1324, 256)
            val secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            val keyBytes = secretKeyFactory.generateSecret(pbKeySpec).encoded
            val keySpec = SecretKeySpec(keyBytes, "AES")

            //Decrypt
            val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
            val ivSpec = IvParameterSpec(iv)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            decrypted = cipher.doFinal(encrypted)
        } catch (e: java.lang.Exception) {
            Log.e("MYAPP", "decryption exception", e)
        }
        return decrypted
    }
}