package com.example.tp3_securedev

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.kittinunf.fuel.httpGet
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec


class MainActivity : AppCompatActivity() {

    companion object CompteSelect {
        var name_compte = ""

        var id= emptyList<String>()
        var name=emptyList<String>()
        var lastname=emptyList<String>()

        var idA= emptyList<String>()
        var accountName=emptyList<String>()
        var amount=emptyList<String>()
        var iban=emptyList<String>()
        var currency=emptyList<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*// Configure sign-in to request the user's ID, email address, and basic profile
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        var mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        val account = GoogleSignIn.getLastSignedInAccount(this)
        findViewById<Button>(R.id.sign_in_button).setOnClickListener(this);*/
    }

    override fun onStart(){
        super.onStart()
        Toast.makeText(applicationContext, "Lancement de l'activity", Toast.LENGTH_SHORT).show();

        this.getString(R.string.url_config).httpGet().responseString()
        { requestC, responseC, resultC ->
            var flag_NoConnexion = (responseC.contentLength==0.toLong());
            if (flag_NoConnexion==false)
            {
                var word = "";
                var flag_category = true;
                var category = "";
                for (e in resultC.component1().toString()) {
                    if ((flag_category == false) and ((e == ',') or (e == '}'))) {
                        flag_category = true;
                        if (category == "id") {
                            id += word
                        }
                        if (category == "name") {
                            name += word
                        }
                        if (category == "lastname") {
                            lastname += word
                        }
                        category = "";
                        word = "";
                    }
                    if ((e != '[') and (e != ']') and (e != '{') and (e != '}') and (e != '"') and (e != ':') and (e != ',')) {
                        word += e;
                    }
                    if ((word == "id") or (word == "name") or (word == "lastname")) {
                        flag_category = false;
                        category = word;
                        word = "";
                    }
                }
                //Encryption
                val id_string = id.toString()
                val id_bytes = id_string.toByteArray()
                val id_map = encryptBytes(id_bytes, "UserSuppliedPassword")
                val lastname_string = lastname.toString()
                val lastname_bytes = lastname_string.toByteArray()
                val lastname_map = encryptBytes(lastname_bytes, "UserSuppliedPassword")
                val name_string = name.toString()
                val name_bytes = name_string.toByteArray()
                val name_map = encryptBytes(name_bytes, "UserSuppliedPassword")

                //Data saving
                val id_fos: FileOutputStream = openFileOutput("id_map.dat", Context.MODE_PRIVATE)
                val id_oos = ObjectOutputStream(id_fos)
                id_oos.writeObject(id_map)
                id_oos.close()
                val lastname_fos: FileOutputStream = openFileOutput(
                    "lastname_map.dat",
                    Context.MODE_PRIVATE
                )
                val lastname_oos = ObjectOutputStream(lastname_fos)
                lastname_oos.writeObject(lastname_map)
                lastname_oos.close()
                val name_fos: FileOutputStream = openFileOutput(
                    "name_map.dat",
                    Context.MODE_PRIVATE
                )
                val name_oos = ObjectOutputStream(name_fos)
                name_oos.writeObject(id_map)
                name_oos.close()

                //Screen display
                val idC = findViewById<TextView>(R.id.text_idC)
                idC.text = id[0];
                val lastnameA = findViewById<TextView>(R.id.text_lastname)
                lastnameA.text = lastname[0];
                val nameA = findViewById<TextView>(R.id.text_name)
                nameA.text = name[0];
            }
            else //No Connexion
            {
                try{    //Some data are stored
                    //Reading
                    val id_objectInputStream = ObjectInputStream(FileInputStream("id_map.dat"))
                    val idRead = id_objectInputStream.readObject()
                    id_objectInputStream.close()
                    val lastname_objectInputStream = ObjectInputStream(FileInputStream("lastname_map.dat"))
                    val lastnameRead = lastname_objectInputStream.readObject()
                    lastname_objectInputStream.close()
                    val name_objectInputStream = ObjectInputStream(FileInputStream("name_map.dat"))
                    val nameRead = name_objectInputStream.readObject()
                    name_objectInputStream.close()

                    //Decryption
                    val id_decrypted = decryptData(
                        idRead as HashMap<String, ByteArray>,
                        "UserSuppliedPassword"
                    )
                    if (id_decrypted != null) {
                        val decryptedString = String(id_decrypted)
                        Log.e("MYAPP", "Decrypted Id String is : $decryptedString")
                    }
                    val lastname_decrypted = decryptData(
                        lastnameRead as HashMap<String, ByteArray>,
                        "UserSuppliedPassword"
                    )
                    if (lastname_decrypted != null) {
                        val decryptedString = String(lastname_decrypted)
                        Log.e("MYAPP", "Decrypted LastName String is : $decryptedString")
                    }
                    val name_decrypted = decryptData(
                        nameRead as HashMap<String, ByteArray>,
                        "UserSuppliedPassword"
                    )
                    if (name_decrypted != null) {
                        val decryptedString = String(name_decrypted)
                        Log.e("MYAPP", "Decrypted Name String is : $decryptedString")
                    }

                    //Screen display
                    val idC = findViewById<TextView>(R.id.text_idC)
                    idC.text = id_decrypted.toString();
                    val lastnameA = findViewById<TextView>(R.id.text_lastname)
                    lastnameA.text = name_decrypted.toString();
                    val nameA = findViewById<TextView>(R.id.text_name)
                    nameA.text = lastname_decrypted.toString();
                }
                catch (e: Exception){   //No data are stored (or data unreadable)
                    val idC = findViewById<TextView>(R.id.text_idC)
                    idC.text = "You should connect the phone a first time to see data.";
                    val lastnameA = findViewById<TextView>(R.id.text_lastname)
                    lastnameA.text = "";
                    val nameA = findViewById<TextView>(R.id.text_name)
                    nameA.text = "";
                }
            }
        }
        this.getString(R.string.url_accounts).httpGet().responseString()
        { requestA, responseA, resultA ->
            var flag_NoConnexion = (responseA.contentLength==0.toLong());
            if (flag_NoConnexion==false)
            {
                var idA= emptyList<String>()
                var accountName=emptyList<String>()
                var amount=emptyList<String>()
                var iban=emptyList<String>()
                var currency=emptyList<String>()

                var word = "";
                var flag_category = true;
                var category = "";
                for (e in resultA.component1().toString()) {
                    if ((flag_category == false) and ((e == ',') or (e == ']'))) {
                        flag_category = true;
                        if (category == "id") {
                            idA += word
                        }
                        if (category == "accountName") {
                            accountName += word
                        }
                        if (category == "amount") {
                            amount += word
                        }
                        if (category == "iban") {
                            iban += word
                        }
                        if (category == "currency") {
                            currency += word
                        }
                        category = "";
                        word = "";
                    }
                    if ((e != '[') and (e != ']') and (e != '{') and (e != '}') and (e != '"') and (e != ':') and (e != ',')) {
                        word += e;
                    }
                    if ((word == "id") or (word == "accountName") or (word == "amount") or (word == "iban") or (word == "currency")) {
                        flag_category = false;
                        category = word;
                        word = "";
                    }
                }
                //Encryption
                val idA_string = idA.toString()
                val idA_bytes = idA_string.toByteArray()
                val idA_map = encryptBytes(idA_bytes, "UserSuppliedPassword")
                val accountName_string = accountName.toString()
                val accountName_bytes = accountName_string.toByteArray()
                val accountName_map = encryptBytes(accountName_bytes, "UserSuppliedPassword")
                val amount_string = amount.toString()
                val amount_bytes = amount_string.toByteArray()
                val amount_map = encryptBytes(amount_bytes, "UserSuppliedPassword")
                val iban_string = iban.toString()
                val iban_bytes = iban_string.toByteArray()
                val iban_map = encryptBytes(iban_bytes, "UserSuppliedPassword")
                val currency_string = currency.toString()
                val currency_bytes = currency_string.toByteArray()
                val currency_map = encryptBytes(currency_bytes, "UserSuppliedPassword")

                //Data saving
                val idA_fos: FileOutputStream = openFileOutput("idA_map.dat", Context.MODE_PRIVATE)
                val idA_oos = ObjectOutputStream(idA_fos)
                idA_oos.writeObject(idA_map)
                idA_oos.close()
                val accountName_fos: FileOutputStream = openFileOutput(
                    "accountName_map.dat",
                    Context.MODE_PRIVATE
                )
                val accountName_oos = ObjectOutputStream(accountName_fos)
                accountName_oos.writeObject(accountName_map)
                accountName_oos.close()
                val amount_fos: FileOutputStream = openFileOutput(
                    "amount_map.dat",
                    Context.MODE_PRIVATE
                )
                val amount_oos = ObjectOutputStream(amount_fos)
                amount_oos.writeObject(amount_map)
                amount_oos.close()
                val iban_fos: FileOutputStream = openFileOutput(
                    "iban_map.dat",
                    Context.MODE_PRIVATE
                )
                val iban_oos = ObjectOutputStream(iban_fos)
                iban_oos.writeObject(iban_map)
                iban_oos.close()
                val currency_fos: FileOutputStream = openFileOutput(
                    "currency_map.dat",
                    Context.MODE_PRIVATE
                )
                val currency_oos = ObjectOutputStream(currency_fos)
                currency_oos.writeObject(currency_map)
                currency_oos.close()

                //Spinner display
                val spinner_comptes = findViewById<Spinner>(R.id.spinner_comptes)
                ArrayAdapter.createFromResource(
                    this,
                    R.array.comptes_array,
                    android.R.layout.simple_spinner_item
                ).also { adapter ->
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner_comptes.adapter = adapter
                }
                var adapter= ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_1,
                    CompteSelect.accountName
                )
                spinner_comptes.adapter=adapter
            }
            else //No Connexion
            {
                try{    //Some data are stored
                    //Reading
                    val accountName_objectInputStream = ObjectInputStream(FileInputStream("accountName_map.dat"))
                    val accountNameRead = accountName_objectInputStream.readObject()
                    accountName_objectInputStream.close()

                    //Decryption
                    val accountName_decrypted = decryptData(
                        accountNameRead as HashMap<String, ByteArray>,
                        "UserSuppliedPassword"
                    )

                    //Spinner display
                    val spinner_comptes = findViewById<Spinner>(R.id.spinner_comptes)
                    ArrayAdapter.createFromResource(
                        this,
                        R.array.comptes_array,
                        android.R.layout.simple_spinner_item
                    ).also { adapter ->
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        spinner_comptes.adapter = adapter
                    }
                    var adapter= ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        accountName_decrypted.toString().toList()
                    )
                    spinner_comptes.adapter=adapter
                }
                catch (e: Exception){   //No data are stored (or data unreadable)
                    //Spinner display
                    val spinner_comptes = findViewById<Spinner>(R.id.spinner_comptes)
                    ArrayAdapter.createFromResource(
                        this,
                        R.array.comptes_array,
                        android.R.layout.simple_spinner_item
                    ).also { adapter ->
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        spinner_comptes.adapter = adapter
                    }
                }
            }
        }

        val button_account= findViewById<Button>(R.id.button_choisir)
        button_account.setOnClickListener {
            val spinner_comptes = findViewById<Spinner>(R.id.spinner_comptes)
            name_compte=spinner_comptes.getSelectedItem().toString();
            val intent = Intent(this, CompteFragment::class.java)
            this.startActivity(intent)
        }

        val buttonRaf = findViewById<Button>(R.id.button_refresh)
        buttonRaf.setOnClickListener {
            this.getString(R.string.url_config).httpGet().responseString()
            { requestC, responseC, resultC ->
                var flag_NoConnexion = (responseC.contentLength==0.toLong());
                if (flag_NoConnexion==false) {
                    var word = "";
                    var flag_category = true;
                    var category = "";
                    for (e in resultC.component1().toString()) {
                        if ((flag_category == false) and ((e == ',') or (e == '}'))) {
                            flag_category = true;
                            if (category == "id") {
                                id += word
                            }
                            if (category == "name") {
                                name += word
                            }
                            if (category == "lastname") {
                                lastname += word
                            }
                            category = "";
                            word = "";
                        }
                        if ((e != '[') and (e != ']') and (e != '{') and (e != '}') and (e != '"') and (e != ':') and (e != ',')) {
                            word += e;
                        }
                        if ((word == "id") or (word == "name") or (word == "lastname")) {
                            flag_category = false;
                            category = word;
                            word = "";
                        }
                    }
                    //Encryption
                    val id_string = id.toString()
                    val id_bytes = id_string.toByteArray()
                    val id_map = encryptBytes(id_bytes, "UserSuppliedPassword")
                    val lastname_string = lastname.toString()
                    val lastname_bytes = lastname_string.toByteArray()
                    val lastname_map = encryptBytes(lastname_bytes, "UserSuppliedPassword")
                    val name_string = name.toString()
                    val name_bytes = name_string.toByteArray()
                    val name_map = encryptBytes(name_bytes, "UserSuppliedPassword")

                    //Data saving
                    val id_fos: FileOutputStream = openFileOutput(
                        "id_map.dat",
                        Context.MODE_PRIVATE
                    )
                    val id_oos = ObjectOutputStream(id_fos)
                    id_oos.writeObject(id_map)
                    id_oos.close()
                    val lastname_fos: FileOutputStream = openFileOutput(
                        "lastname_map.dat",
                        Context.MODE_PRIVATE
                    )
                    val lastname_oos = ObjectOutputStream(lastname_fos)
                    lastname_oos.writeObject(lastname_map)
                    lastname_oos.close()
                    val name_fos: FileOutputStream = openFileOutput(
                        "name_map.dat",
                        Context.MODE_PRIVATE
                    )
                    val name_oos = ObjectOutputStream(name_fos)
                    name_oos.writeObject(id_map)
                    name_oos.close()

                    //Screen display
                    val idC = findViewById<TextView>(R.id.text_idC)
                    idC.text = id[0];
                    val lastnameA = findViewById<TextView>(R.id.text_lastname)
                    lastnameA.text = lastname[0];
                    val nameA = findViewById<TextView>(R.id.text_name)
                    nameA.text = name[0];
                }
            }
            this.getString(R.string.url_accounts).httpGet().responseString()
            { requestA, responseA, resultA ->
                var word = "";
                var flag_category = true;
                var category = "";
                for (e in resultA.component1().toString()) {
                    if ((flag_category == false) and ((e == ',') or (e == ']'))) {
                        flag_category = true;
                        if (category == "id") {
                            idA += word
                        }
                        if (category == "accountName") {
                            accountName += word
                        }
                        if (category == "amount") {
                            amount += word
                        }
                        if (category == "iban") {
                            iban += word
                        }
                        if (category == "currency") {
                            currency += word
                        }
                        category = "";
                        word = "";
                    }
                    if ((e != '[') and (e != ']') and (e != '{') and (e != '}') and (e != '"') and (e != ':') and (e != ',')) {
                        word += e;
                    }
                    if ((word == "id") or (word == "accountName") or (word == "amount") or (word == "iban") or (word == "currency")) {
                        flag_category = false;
                        category = word;
                        word = "";
                    }
                }
                //Encryption
                val idA_string = idA.toString()
                val idA_bytes = idA_string.toByteArray()
                val idA_map = encryptBytes(idA_bytes, "UserSuppliedPassword")
                val accountName_string = accountName.toString()
                val accountName_bytes = accountName_string.toByteArray()
                val accountName_map = encryptBytes(accountName_bytes, "UserSuppliedPassword")
                val amount_string = amount.toString()
                val amount_bytes = amount_string.toByteArray()
                val amount_map = encryptBytes(amount_bytes, "UserSuppliedPassword")
                val iban_string = iban.toString()
                val iban_bytes = iban_string.toByteArray()
                val iban_map = encryptBytes(iban_bytes, "UserSuppliedPassword")
                val currency_string = currency.toString()
                val currency_bytes = currency_string.toByteArray()
                val currency_map = encryptBytes(currency_bytes, "UserSuppliedPassword")

                //Data saving
                val idA_fos: FileOutputStream = openFileOutput("idA_map.dat", Context.MODE_PRIVATE)
                val idA_oos = ObjectOutputStream(idA_fos)
                idA_oos.writeObject(idA_map)
                idA_oos.close()
                val accountName_fos: FileOutputStream = openFileOutput(
                    "accountName_map.dat",
                    Context.MODE_PRIVATE
                )
                val accountName_oos = ObjectOutputStream(accountName_fos)
                accountName_oos.writeObject(accountName_map)
                accountName_oos.close()
                val amount_fos: FileOutputStream = openFileOutput(
                    "amount_map.dat",
                    Context.MODE_PRIVATE
                )
                val amount_oos = ObjectOutputStream(amount_fos)
                amount_oos.writeObject(amount_map)
                amount_oos.close()
                val iban_fos: FileOutputStream = openFileOutput(
                    "iban_map.dat",
                    Context.MODE_PRIVATE
                )
                val iban_oos = ObjectOutputStream(iban_fos)
                iban_oos.writeObject(iban_map)
                iban_oos.close()
                val currency_fos: FileOutputStream = openFileOutput(
                    "currency_map.dat",
                    Context.MODE_PRIVATE
                )
                val currency_oos = ObjectOutputStream(currency_fos)
                currency_oos.writeObject(currency_map)
                currency_oos.close()

                //Spinner display
                val spinner_comptes = findViewById<Spinner>(R.id.spinner_comptes)
                ArrayAdapter.createFromResource(
                    this,
                    R.array.comptes_array,
                    android.R.layout.simple_spinner_item
                ).also { adapter ->
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner_comptes.adapter = adapter
                }
                var adapter= ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_1,
                    CompteSelect.accountName
                )
                spinner_comptes.adapter=adapter
            }
            Toast.makeText(applicationContext, "Informations actualisées", Toast.LENGTH_SHORT).show();
            println("Informations actualisées")
        }
    }
    private fun encryptBytes(plainTextBytes: ByteArray, passwordString: String): HashMap<String, ByteArray>? {
        val map = HashMap<String, ByteArray>()
        try {
            //Random salt for next step
            val random = SecureRandom()
            val salt = ByteArray(256)
            random.nextBytes(salt)

            //PBKDF2 - derive the key from the password, don't use passwords directly
            val passwordChar = passwordString.toCharArray() //Turn password into char[] array
            val pbKeySpec = PBEKeySpec(passwordChar, salt, 1324, 256) //1324 iterations
            val secretKeyFactory: SecretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            val keyBytes: ByteArray = secretKeyFactory.generateSecret(pbKeySpec).getEncoded()
            val keySpec = SecretKeySpec(keyBytes, "AES")

            //Create initialization vector for AES
            val ivRandom = SecureRandom() //not caching previous seeded instance of SecureRandom
            val iv = ByteArray(16)
            ivRandom.nextBytes(iv)
            val ivSpec = IvParameterSpec(iv)

            //Encrypt
            val cipher: Cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            val encrypted: ByteArray = cipher.doFinal(plainTextBytes)
            map["salt"] = salt
            map["iv"] = iv
            map["encrypted"] = encrypted
        } catch (e: Exception) {
            Log.e("MYAPP", "encryption exception", e)
        }
        return map
    }

    private fun decryptData(map: HashMap<String, ByteArray>, passwordString: String): ByteArray? {
        var decrypted: ByteArray? = null
        try {
            val salt = map["salt"]
            val iv = map["iv"]
            val encrypted = map["encrypted"]

            //regenerate key from password
            val passwordChar = passwordString.toCharArray()
            val pbKeySpec = PBEKeySpec(passwordChar, salt, 1324, 256)
            val secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            val keyBytes = secretKeyFactory.generateSecret(pbKeySpec).encoded
            val keySpec = SecretKeySpec(keyBytes, "AES")

            //Decrypt
            val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
            val ivSpec = IvParameterSpec(iv)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            decrypted = cipher.doFinal(encrypted)
        } catch (e: java.lang.Exception) {
            Log.e("MYAPP", "decryption exception", e)
        }
        return decrypted
    }
    /*fun onClick(v: View) {
        when (v.getId()) {
            R.id.sign_in_button -> signIn()
        }
    }
    open fun signIn() {
        val signInIntent: Intent = mGoogleSignInClient.getSignInIntent()
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    open fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }
    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)

            // Signed in successfully, show authenticated UI.
            updateUI(account)
        } catch (e: ApiException) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.statusCode)
            updateUI(null)
        }
    }*/
}